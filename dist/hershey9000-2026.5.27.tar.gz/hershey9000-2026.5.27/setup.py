# MISSION: Inject the support files. Modernized.
# STATUS: Public Release
# VERSION: 2.0.0
# NOTES: See https://github.com/soft9000/PyHershey
# FILE: setup.py
# AUTHOR: See https://ko-fi.com/randallnagy
#
from setuptools import setup, find_packages, find_namespace_packages

# defer to README.md:
long_description= '''
THE DEMO
========
To enjoy the line x line rendering
of Hershey's amazingly cool font set:

>> import Hershey01

FONT DEMO
=========
To use the fonts in your project,
review TurtleShow.py and / or check
the project doc at https://github.com/soft9000/PyHershey

FONT PDF
========
In addition to re-using my code you
might also like to review the .PDFs:

https://github.com/soft9000/The-Book-of-Glyphs/tree/master/TheHersheyFonts
'''

setup(name='Hershey9000',
      author="Randall Nagy",
      version="2026.05.27",
      description="Hershey's Fonts & that 'TurtleShow' Viewer",
      author_email="r.a.nagy@gmail.com",
      url="http://soft9000.com",
      download_url="https://github.com/soft9000/PyHershey",
      platforms="Turtle Graphics Required",
      packages=find_namespace_packages(),
      include_package_data=True,
      package_data= {
          "Hershey9000" : ["GsDict/*.gsdict"],
          }
)
