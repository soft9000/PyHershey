try:
    from Hershey01 import TurtleShow
except Exception as ex:
    print(ex)
finally:
    print("\n\nDone.")
