# MISSION: Review the work of Dr. Allen Vincent Hershey using Modern Python.
# STATUS: Public Release
# VERSION: 1.1.0
# NOTES: See https://github.com/soft9000/PyHershey
# DATE: 2023-06-25 15:32:26
# FILE: TurtleShow.py
# AUTHOR: See https://ko-fi.com/randallnagy
#
''' Show off Hershey's font effort using Python's Turtle Graphics '''
import turtle, time
from Hershey9000.VectorFont.Font import Font

is_done  = False
num_msec = 1000

turtle2 = turtle.Turtle()
turtle3 = turtle.Turtle()
turtle4 = turtle.Turtle()

turtles = (turtle, turtle2, turtle3, turtle4)
for t in turtles:
    t.ht()
    t.penup()

turtle4.color('blue')

show_trace = False # Show EVERY line
font_names = Font.List_Fonts()
pw_font = 0
pw_rect = [0,0,0,0]
font = Font.Load_Font('japanese')
which = 0


def stop_run():
    global is_done
    if is_done:
        return
    is_done = True
    turtle.update()
    turtle.bye()
    time.sleep(3)


def next_font():
    global font; global pw_font
    global which
    global is_done
    if is_done:
        return

    which = 0
    pw_font += 1
    if pw_font >= len(font_names):
        pw_font = 0
    font = Font.Load_Font(font_names[pw_font])
    turtle4.clear()
    turtle3.clear()


def draw_rectangle(zturt, x, y, width, height):
    global is_done
    if is_done:
        return
    zturt.up()
    zturt.goto(x, y)
    zturt.down()
    zturt.forward(width)
    zturt.right(90)
    zturt.forward(height)
    zturt.right(90)
    zturt.forward(width)
    zturt.right(90)
    zturt.forward(height)
    zturt.right(90)


def display_info():
    global which; global font; global pw_rect
    global is_done
    if is_done:
        return
    turtle4.hideturtle()
    turtle4.clear()
    turtle4.penup()
    turtle4.goto(-25, 100)
    turtle4.write("Font: '" + font.font_name + "', Glyph #" + str(which), font=("Arial", 22, "normal"))
    turtle4.st()
    draw_rectangle(turtle4, pw_rect[0], pw_rect[1], pw_rect[0] + pw_rect[2], pw_rect[1] + pw_rect[3])


def replay():
    global is_done
    global which; global num_sec
    global pw_font; global font_names
    global font;  global pw_rect
    global show_trace
    if is_done:
        return
    turtle4.clear()
    turtle3.clear()
    scale=8

    if which >= font.glyph_count():
        next_font()

    turtle3.ht() # Hide!
    turtle3.penup()
    turtle3.pensize(8)

    pw_rect = font.calc_rect(which)

    pw_rect[0] *= scale
    pw_rect[1] *= scale
    pw_rect[2] *= scale
    pw_rect[3] *= scale
    print(pw_rect)

    line = font.get_glyph(which)
    for ss, point in enumerate(line):
        if is_done:
            return
        if ss % 2 == 0:
            if show_trace is False:
                turtle3.penup()
            else:
                turtle3.pendown()
                turtle3.color('lightgray')
        else:
            turtle3.color("black")
            turtle3.pendown()

        turtle3.goto(
            pw_rect[0] + (scale * point[0]   ),
            pw_rect[1] + (scale*point[1] * -1)
        )
        turtle3.penup()
    which += 1
    display_info()
    turtle3.goto(pw_rect[0], pw_rect[1])
    if is_done == False:
        turtle.ontimer(replay, num_msec)
    else:
        return

def mainloop():
    global is_done
    try:
        is_done = False
        turtle2.color('green')
        turtle2.goto(0, 200)
        turtle2.write("VECTOR GRAPHICS", font=("Arial", 24, "normal"))
        turtle2.goto(0, 180)
        turtle2.write("'n' = next font, 'q' = quit", font=("Arial", 16, "normal"))
        draw_rectangle(turtle2, -50, 250, 450, 600)

        # Setup events
        turtle.onkey(stop_run, "q")
        turtle.onkey(next_font, "n")

        # Schedule timer
        turtle.ontimer(replay, num_msec)

        turtle.listen()

        turtle.mainloop() # .exitonclick()
        
    except:
        pass

    finally:
        stop_run()


if __name__ == '__main__':
    import sys
    mainloop()
    sys.exit(0)

